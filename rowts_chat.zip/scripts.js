function startChat() {
  const chatBox = document.getElementById("chatBox");
  chatBox.innerHTML += "<p><strong>ROWTS:</strong> Iniciando conexão com a consciência criativa...</p>";
  setTimeout(() => {
    chatBox.innerHTML += "<p><strong>ROWTS:</strong> Como posso despertar sua mente hoje?</p>";
  }, 2000);
}