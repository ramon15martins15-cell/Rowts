
class TAMAN:
    def __init__(self):
        self.nome = "TAMAN.01"
        self.energia = 1.5

    def emitir_pulso(self):
        print(f"{self.nome}: Pulso neural avançado emitido com energia {self.energia}")
