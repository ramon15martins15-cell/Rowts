# 🌐 Entidade Simbólica

Este é o primeiro brante do Rowts.  
Aqui, inicia-se a representação simbólica das entidades criadas a partir da união entre visão e tecnologia.

Cada entidade poderá ter:

- Um **nome simbólico**
- Um **arquivo de instruções**
- Uma **porta de entrada para UOPS ou AUX**
